const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());

const conexion = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Pon tu contraseña de MySQL aquí si tienes una
    database: 'tienda_videojuegos'
});

conexion.connect(err => {
    if (err) { console.error('Error de conexión: ', err); return; }
    console.log('Conectado a MySQL');
});

app.get('/categorias', (req, res) => {
    conexion.query('SELECT * FROM categorias', (err, resultados) => {
        if (err) throw err;
        res.json(resultados);
    });
});

app.get('/plataformas', (req, res) => {
    conexion.query('SELECT * FROM plataformas', (err, resultados) => {
        if (err) throw err;
        res.json(resultados);
    });
});

app.get('/juegos', (req, res) => {
    const sql = `
        SELECT j.id, j.titulo, c.nombre AS categoria, p.nombre AS plataforma, 
               j.stock, j.precio, (j.stock * j.precio) AS total_inventario
        FROM juegos j
        INNER JOIN categorias c ON j.categoria_id = c.id
        INNER JOIN plataformas p ON j.plataforma_id = p.id
    `;
    conexion.query(sql, (err, resultados) => {
        if (err) throw err;
        res.json(resultados);
    });
});

app.post('/juegos', (req, res) => {
    const { titulo, categoria_id, plataforma_id, stock, precio } = req.body;
    conexion.query(
        'INSERT INTO juegos (titulo, categoria_id, plataforma_id, stock, precio) VALUES (?, ?, ?, ?, ?)',
        [titulo, categoria_id, plataforma_id, stock, precio],
        err => {
            if (err) throw err;
            res.send({ message: 'Juego registrado correctamente' });
        }
    );
});

app.delete('/juegos/:id', (req, res) => {
    const id = req.params.id;
    conexion.query('DELETE FROM juegos WHERE id=?', [id], err => {
        if (err) throw err;
        res.send({ message: `Juego con ID ${id} eliminado` });
    });
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
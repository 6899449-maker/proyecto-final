import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ListaJuegos() {
  const [juegos, setJuegos] = useState([]);
  const [titulo, setTitulo] = useState('');
  const [categoria_id, setCategoriaId] = useState('');
  const [plataforma_id, setPlataformaId] = useState('');
  const [stock, setStock] = useState('');
  const [precio, setPrecio] = useState('');

  const cargarJuegos = () => {
    axios.get('http://localhost:3000/juegos')
      .then(res => setJuegos(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    cargarJuegos();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:3000/juegos', { titulo, categoria_id, plataforma_id, stock, precio })
      .then(res => {
        alert(res.data.message);
        setTitulo(''); setStock(''); setPrecio(''); setCategoriaId(''); setPlataformaId('');
        cargarJuegos();
      })
      .catch(err => console.error(err));
  };

  const eliminarJuego = (id) => {
    if (window.confirm('¿Eliminar este juego?')) {
      axios.delete(`http://localhost:3000/juegos/${id}`)
        .then(res => { alert(res.data.message); cargarJuegos(); })
        .catch(err => console.error(err));
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h2>Tienda de Videojuegos</h2>
      
      <form onSubmit={handleSubmit} style={{ marginBottom: '20px', background: '#f4f4f4', padding: '15px' }}>
        <h3>Registrar Juego</h3>
        <input type="text" placeholder="Título del juego" value={titulo} onChange={e => setTitulo(e.target.value)} required /><br/><br/>
        <input type="number" placeholder="ID Categoría (pon 1)" value={categoria_id} onChange={e => setCategoriaId(e.target.value)} required /><br/><br/>
        <input type="number" placeholder="ID Plataforma (pon 1)" value={plataforma_id} onChange={e => setPlataformaId(e.target.value)} required /><br/><br/>
        <input type="number" placeholder="Stock" value={stock} onChange={e => setStock(e.target.value)} required /><br/><br/>
        <input type="number" step="0.01" placeholder="Precio" value={precio} onChange={e => setPrecio(e.target.value)} required /><br/><br/>
        <button type="submit">Guardar Juego</button>
      </form>

      <table border="1" cellPadding="8">
        <thead>
          <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Categoría</th>
            <th>Plataforma</th>
            <th>Stock</th>
            <th>Precio</th>
            <th>Total</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {juegos.map(j => (
            <tr key={j.id}>
              <td>{j.id}</td>
              <td>{j.titulo}</td>
              <td>{j.categoria}</td>
              <td>{j.plataforma}</td>
              <td>{j.stock}</td>
              <td>${j.precio}</td>
              <td>${j.total_inventario}</td>
              <td>
                <button onClick={() => eliminarJuego(j.id)} style={{ backgroundColor: 'red', color: 'white' }}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default ListaJuegos;
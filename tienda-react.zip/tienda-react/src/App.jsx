import React from 'react';
import ListaJuegos from './components/ListaJuegos';

function App() {
  return (
    <div>
      <ListaJuegos />
    </div>
  );
}

export default App;